package com.anish.ccproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RateAppActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate_app);
    }
}